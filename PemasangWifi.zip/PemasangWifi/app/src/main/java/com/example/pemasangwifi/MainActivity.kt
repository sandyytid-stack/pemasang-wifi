package com.example.pemasangwifi

import android.app.Application
import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

val STATUS = listOf("Prospek", "Janji survei", "Sudah dipasang", "Batal")
val SINYAL = listOf("Kuat", "Sedang", "Lemah")
val Biru = Color(0xFF2563EB)

// Catatan: kolom "wilayah" dipakai sebagai alamat, "tarif" sebagai paket FWA,
// dan "terpasang" dipertahankan agar database lama tetap cocok.
@Entity(tableName = "pemasang")
data class Pemasang(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nama: String, val wilayah: String, val telepon: String,
    val tarif: String, val catatan: String, val favorit: Boolean = false,
    val koordinat: String = "", val terpasang: Boolean = false,
    val status: String = "Prospek", val sinyal: String = "", val followUp: String = ""
)

@Dao interface PemasangDao {
    @Query("SELECT * FROM pemasang ORDER BY favorit DESC, nama ASC") fun semua(): Flow<List<Pemasang>>
    @Upsert suspend fun simpan(p: Pemasang)
    @Delete suspend fun hapus(p: Pemasang)
}

val M1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE pemasang ADD COLUMN koordinat TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE pemasang ADD COLUMN terpasang INTEGER NOT NULL DEFAULT 0")
    }
}
val M2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE pemasang ADD COLUMN status TEXT NOT NULL DEFAULT 'Prospek'")
        db.execSQL("ALTER TABLE pemasang ADD COLUMN sinyal TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE pemasang ADD COLUMN followUp TEXT NOT NULL DEFAULT ''")
        db.execSQL("UPDATE pemasang SET status = 'Sudah dipasang' WHERE terpasang = 1")
    }
}

@Database(entities = [Pemasang::class], version = 3, exportSchema = false)
abstract class Db : RoomDatabase() { abstract fun dao(): PemasangDao }

class VM(app: Application) : AndroidViewModel(app) {
    private val dao = Room.databaseBuilder(app, Db::class.java, "wifi.db").addMigrations(M1_2, M2_3).build().dao()
    val data = dao.semua().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    fun simpan(p: Pemasang) = viewModelScope.launch { dao.simpan(p) }
    fun hapus(p: Pemasang) = viewModelScope.launch { dao.hapus(p) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Tema { Layar() } }
    }
}

@Composable
fun Tema(isi: @Composable () -> Unit) = MaterialTheme(
    colorScheme = lightColorScheme(
        primary = Biru, background = Color(0xFFF5F7FB), surface = Color.White,
        onSurface = Color(0xFF1B1F2A), onSurfaceVariant = Color(0xFF6B7280),
        outline = Color(0xFFE3E7EF), primaryContainer = Color(0xFFE0E9FF)
    ),
    content = isi
)

fun nomor62(t: String): String {
    val d = t.filter { it.isDigit() }
    return if (d.startsWith("0")) "62" + d.drop(1) else d
}

fun buka(ctx: Context, i: Intent) { runCatching { ctx.startActivity(i) } }

fun warnaStatus(s: String): Pair<Color, Color> = when (s) {
    "Sudah dipasang" -> Color(0xFFDCFCE7) to Color(0xFF15803D)
    "Janji survei" -> Color(0xFFFEF3C7) to Color(0xFFB45309)
    "Batal" -> Color(0xFFFEE2E2) to Color(0xFFB91C1C)
    else -> Color(0xFFE0E9FF) to Color(0xFF1D4ED8)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Layar(vm: VM = viewModel()) {
    val data by vm.data.collectAsState()
    val warna = MaterialTheme.colorScheme
    var cari by remember { mutableStateOf("") }
    var hanyaFav by remember { mutableStateOf(false) }
    var filterStatus by remember { mutableStateOf<String?>(null) }
    var edit by remember { mutableStateOf<Pemasang?>(null) }
    var dialog by remember { mutableStateOf(false) }

    val tampil = data.filter {
        (!hanyaFav || it.favorit) && (filterStatus == null || it.status == filterStatus) &&
            (it.nama.contains(cari, true) || it.wilayah.contains(cari, true))
    }

    Scaffold(
        containerColor = warna.background,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { edit = null; dialog = true },
                containerColor = Biru, contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, null) }, text = { Text("Tambah") }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(20.dp))
            Text("Sales FWA", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("${data.size} pelanggan dan prospek", color = warna.onSurfaceVariant)
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(cari, { cari = it }, Modifier.fillMaxWidth(),
                placeholder = { Text("Cari nama atau alamat") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true, shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                    unfocusedBorderColor = warna.outline))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(hanyaFav, { hanyaFav = !hanyaFav }, { Text("Favorit") }, shape = RoundedCornerShape(50))
                STATUS.forEach { s ->
                    FilterChip(filterStatus == s, { filterStatus = if (filterStatus == s) null else s },
                        { Text("$s (${data.count { it.status == s }})") }, shape = RoundedCornerShape(50))
                }
            }
            if (tampil.isEmpty()) Text("Belum ada data. Tekan Tambah untuk memulai.", color = warna.onSurfaceVariant)
            LazyColumn(contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tampil, key = { it.id }) { p -> Kartu(p, vm) { edit = p; dialog = true } }
            }
        }
    }

    if (dialog) FormDialog(edit, { dialog = false }) { vm.simpan(it); dialog = false }
}

@Composable
fun Tombol(teks: String, modifier: Modifier, aksi: () -> Unit) {
    Box(modifier.height(30.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFEEF2FF)).clickable(onClick = aksi),
        contentAlignment = Alignment.Center) {
        Text(teks, color = Biru, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Kartu(p: Pemasang, vm: VM, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    val warna = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf(false) }
    var menuStatus by remember { mutableStateOf(false) }
    val (bg, fg) = warnaStatus(p.status)
    val kecil = MaterialTheme.typography.bodySmall
    val info = listOf(p.telepon, p.tarif, if (p.sinyal.isBlank()) "" else "Sinyal ${p.sinyal}")
        .filter { it.isNotBlank() }.joinToString("  •  ")
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, warna.outline)) {
        Column(Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(34.dp).clip(CircleShape).background(warna.primaryContainer), contentAlignment = Alignment.Center) {
                    Text(p.nama.take(1).uppercase(), color = Biru, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(p.nama, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                        if (p.favorit) Icon(Icons.Default.Favorite, "Favorit", Modifier.padding(start = 4.dp).size(14.dp), tint = Color(0xFFE11D48))
                    }
                    Text(p.wilayah, style = kecil, color = warna.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Spacer(Modifier.width(6.dp))
                Box {
                    Box(Modifier.clip(RoundedCornerShape(50)).background(bg).clickable { menuStatus = true }
                        .padding(horizontal = 8.dp, vertical = 3.dp)) {
                        Text("${p.status} ▾", color = fg, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Medium)
                    }
                    DropdownMenu(menuStatus, { menuStatus = false }) {
                        STATUS.forEach { s ->
                            DropdownMenuItem({ Text(s) }, {
                                menuStatus = false
                                vm.simpan(p.copy(status = s, terpasang = s == "Sudah dipasang"))
                            })
                        }
                    }
                }
                Box {
                    Box(Modifier.size(32.dp).clip(CircleShape).clickable { menu = true }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.MoreVert, "Menu", Modifier.size(20.dp), tint = warna.onSurfaceVariant)
                    }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text(if (p.favorit) "Hapus favorit" else "Jadikan favorit") },
                            { menu = false; vm.simpan(p.copy(favorit = !p.favorit)) })
                        DropdownMenuItem({ Text("Ubah") }, { menu = false; onEdit() })
                        DropdownMenuItem({ Text("Hapus") }, { menu = false; vm.hapus(p) })
                    }
                }
            }
            if (info.isNotBlank()) Text(info, style = kecil, modifier = Modifier.padding(top = 6.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (p.followUp.isNotBlank()) Text("Follow-up: ${p.followUp}", style = kecil, color = warna.onSurfaceVariant)
            if (p.catatan.isNotBlank()) Text(p.catatan, style = kecil, color = warna.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Tombol("Telepon", Modifier.weight(1f)) { buka(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:${p.telepon}"))) }
                Tombol("WhatsApp", Modifier.weight(1f)) {
                    val pesan = "Halo ${p.nama}, saya sales internet rumah FWA. Boleh saya jelaskan paket dan cek sinyal di lokasi Anda?"
                    buka(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${nomor62(p.telepon)}?text=${Uri.encode(pesan)}")))
                }
                if (p.koordinat.isNotBlank()) Tombol("Peta", Modifier.weight(1f)) {
                    val q = p.koordinat.replace(" ", "")
                    buka(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q(${Uri.encode(p.nama)})")))
                }
            }
        }
    }
}

@Composable
fun FormDialog(awal: Pemasang?, tutup: () -> Unit, simpan: (Pemasang) -> Unit) {
    val ctx = LocalContext.current
    var nama by remember { mutableStateOf(awal?.nama ?: "") }
    var alamat by remember { mutableStateOf(awal?.wilayah ?: "") }
    var telp by remember { mutableStateOf(awal?.telepon ?: "") }
    var paket by remember { mutableStateOf(awal?.tarif ?: "") }
    var catatan by remember { mutableStateOf(awal?.catatan ?: "") }
    var koor by remember { mutableStateOf(awal?.koordinat ?: "") }
    var status by remember { mutableStateOf(awal?.status ?: "Prospek") }
    var sinyal by remember { mutableStateOf(awal?.sinyal ?: "") }
    var followUp by remember { mutableStateOf(awal?.followUp ?: "") }
    val koorOk = koor.isBlank() || Regex("""^-?\d{1,3}(\.\d+)?\s*,\s*-?\d{1,3}(\.\d+)?$""").matches(koor.trim())
    AlertDialog(
        onDismissRequest = tutup, containerColor = Color.White, shape = RoundedCornerShape(20.dp),
        title = { Text(if (awal == null) "Tambah pelanggan" else "Ubah pelanggan") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(nama, { nama = it }, label = { Text("Nama") }, singleLine = true)
                OutlinedTextField(telp, { telp = it }, label = { Text("No. HP") }, singleLine = true)
                OutlinedTextField(alamat, { alamat = it }, label = { Text("Alamat") })
                OutlinedTextField(paket, { paket = it }, label = { Text("Paket FWA") }, singleLine = true)
                OutlinedTextField(koor, { koor = it }, label = { Text("Koordinat (lat, long)") },
                    placeholder = { Text("-6.914744, 107.609810") }, singleLine = true, isError = !koorOk,
                    supportingText = { Text(if (koorOk) "Salin dari Google Maps" else "Format: -6.914744, 107.609810") })
                Text("Status", style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    STATUS.forEach { s -> FilterChip(status == s, { status = s }, { Text(s) }) }
                }
                Text("Sinyal di lokasi", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SINYAL.forEach { s -> FilterChip(sinyal == s, { sinyal = if (sinyal == s) "" else s }, { Text(s) }) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton({
                        val c = Calendar.getInstance()
                        DatePickerDialog(ctx, { _, y, m, d -> followUp = "%02d/%02d/%d".format(d, m + 1, y) },
                            c[Calendar.YEAR], c[Calendar.MONTH], c[Calendar.DAY_OF_MONTH]).show()
                    }) { Text(if (followUp.isBlank()) "Pilih tanggal follow-up" else "Follow-up: $followUp") }
                    if (followUp.isNotBlank()) TextButton({ followUp = "" }) { Text("Hapus") }
                }
                OutlinedTextField(catatan, { catatan = it }, label = { Text("Catatan") })
            }
        },
        confirmButton = {
            TextButton(enabled = nama.isNotBlank() && telp.isNotBlank() && koorOk, onClick = {
                simpan((awal ?: Pemasang(nama = "", wilayah = "", telepon = "", tarif = "", catatan = ""))
                    .copy(nama = nama.trim(), wilayah = alamat.trim(), telepon = telp.trim(), tarif = paket.trim(),
                        catatan = catatan.trim(), koordinat = koor.trim(), status = status, sinyal = sinyal,
                        followUp = followUp, terpasang = status == "Sudah dipasang"))
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(tutup) { Text("Batal") } }
    )
}
