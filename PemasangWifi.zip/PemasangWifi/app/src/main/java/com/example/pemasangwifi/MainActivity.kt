package com.example.pemasangwifi

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@Entity(tableName = "pemasang")
data class Pemasang(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nama: String, val wilayah: String, val telepon: String,
    val tarif: String, val catatan: String, val favorit: Boolean = false,
    val koordinat: String = "", val terpasang: Boolean = false
)

@Dao interface PemasangDao {
    @Query("SELECT * FROM pemasang ORDER BY favorit DESC, nama ASC") fun semua(): Flow<List<Pemasang>>
    @Upsert suspend fun simpan(p: Pemasang)
    @Delete suspend fun hapus(p: Pemasang)
}

val M1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE pemasang ADD COLUMN koordinat TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE pemasang ADD COLUMN terpasang INTEGER NOT NULL DEFAULT 0")
    }
}

@Database(entities = [Pemasang::class], version = 2, exportSchema = false)
abstract class Db : RoomDatabase() { abstract fun dao(): PemasangDao }

class VM(app: Application) : AndroidViewModel(app) {
    private val dao = Room.databaseBuilder(app, Db::class.java, "wifi.db").addMigrations(M1_2).build().dao()
    val data = dao.semua().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    fun simpan(p: Pemasang) = viewModelScope.launch { dao.simpan(p) }
    fun hapus(p: Pemasang) = viewModelScope.launch { dao.hapus(p) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Tema { Layar() } }
    }
}

fun nomor62(t: String): String {
    val d = t.filter { it.isDigit() }
    return if (d.startsWith("0")) "62" + d.drop(1) else d
}

val Biru = Color(0xFF2563EB)

@Composable
fun Tema(isi: @Composable () -> Unit) = MaterialTheme(
    colorScheme = lightColorScheme(
        primary = Biru, background = Color(0xFFF5F7FB), surface = Color.White,
        onSurface = Color(0xFF1B1F2A), onSurfaceVariant = Color(0xFF6B7280),
        outline = Color(0xFFE3E7EF), primaryContainer = Color(0xFFE0E9FF)
    ),
    content = isi
)

fun buka(ctx: Context, i: Intent) { runCatching { ctx.startActivity(i) } }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Layar(vm: VM = viewModel()) {
    val data by vm.data.collectAsState()
    val warna = MaterialTheme.colorScheme
    var cari by remember { mutableStateOf("") }
    var hanyaFav by remember { mutableStateOf(false) }
    var filterStatus by remember { mutableStateOf<Boolean?>(null) }
    var edit by remember { mutableStateOf<Pemasang?>(null) }
    var dialog by remember { mutableStateOf(false) }

    val tampil = data.filter {
        (!hanyaFav || it.favorit) && (filterStatus == null || it.terpasang == filterStatus) &&
            (it.nama.contains(cari, true) || it.wilayah.contains(cari, true))
    }

    Scaffold(
        containerColor = warna.background,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { edit = null; dialog = true },
                containerColor = Biru, contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, null) }, text = { Text("Tambah") }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(20.dp))
            Text("Pemasang WiFi", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("${data.size} pemasang  •  ${data.count { it.terpasang }} sudah dipasang", color = warna.onSurfaceVariant)
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(cari, { cari = it }, Modifier.fillMaxWidth(),
                placeholder = { Text("Cari nama atau wilayah") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true, shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                    unfocusedBorderColor = warna.outline))
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(hanyaFav, { hanyaFav = !hanyaFav }, { Text("Favorit") }, shape = RoundedCornerShape(50))
                FilterChip(filterStatus == false, { filterStatus = if (filterStatus == false) null else false }, { Text("Belum dipasang") }, shape = RoundedCornerShape(50))
                FilterChip(filterStatus == true, { filterStatus = if (filterStatus == true) null else true }, { Text("Sudah dipasang") }, shape = RoundedCornerShape(50))
            }
            if (tampil.isEmpty()) Text("Belum ada data. Tekan Tambah untuk memulai.", color = warna.onSurfaceVariant)
            LazyColumn(contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(tampil, key = { it.id }) { p -> Kartu(p, vm) { edit = p; dialog = true } }
            }
        }
    }

    if (dialog) FormDialog(edit, { dialog = false }) { vm.simpan(it); dialog = false }
}

@Composable
fun Kartu(p: Pemasang, vm: VM, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    val warna = MaterialTheme.colorScheme
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, warna.outline)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(warna.primaryContainer), contentAlignment = Alignment.Center) {
                    Text(p.nama.take(1).uppercase(), color = Biru, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.nama, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(p.wilayah, style = MaterialTheme.typography.bodySmall, color = warna.onSurfaceVariant)
                }
                IconButton({ vm.simpan(p.copy(favorit = !p.favorit)) }) {
                    Icon(if (p.favorit) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorit",
                        tint = if (p.favorit) Color(0xFFE11D48) else warna.onSurfaceVariant)
                }
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "Menu", tint = warna.onSurfaceVariant) }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text("Ubah") }, { menu = false; onEdit() })
                        DropdownMenuItem({ Text("Hapus") }, { menu = false; vm.hapus(p) })
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(p.telepon, style = MaterialTheme.typography.bodyMedium)
            if (p.tarif.isNotBlank()) Text("Tarif: ${p.tarif}", style = MaterialTheme.typography.bodyMedium, color = warna.onSurfaceVariant)
            if (p.koordinat.isNotBlank()) Text("Koordinat: ${p.koordinat}", style = MaterialTheme.typography.bodySmall, color = warna.onSurfaceVariant)
            if (p.catatan.isNotBlank()) Text(p.catatan, style = MaterialTheme.typography.bodySmall, color = warna.onSurfaceVariant)
            Spacer(Modifier.height(10.dp))
            Box(Modifier.clip(RoundedCornerShape(50))
                .background(if (p.terpasang) Color(0xFFDCFCE7) else Color(0xFFFEF3C7))
                .clickable { vm.simpan(p.copy(terpasang = !p.terpasang)) }
                .padding(horizontal = 12.dp, vertical = 5.dp)) {
                Text(if (p.terpasang) "Sudah dipasang" else "Belum dipasang",
                    color = if (p.terpasang) Color(0xFF15803D) else Color(0xFFB45309),
                    style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = warna.outline)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val kecil = PaddingValues(horizontal = 4.dp)
                FilledTonalButton({ buka(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:${p.telepon}"))) },
                    Modifier.weight(1f), contentPadding = kecil) { Text("Telepon") }
                FilledTonalButton({ buka(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${nomor62(p.telepon)}"))) },
                    Modifier.weight(1f), contentPadding = kecil) { Text("WhatsApp") }
                if (p.koordinat.isNotBlank()) FilledTonalButton({
                    val q = p.koordinat.replace(" ", "")
                    buka(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q(${Uri.encode(p.nama)})")))
                }, Modifier.weight(1f), contentPadding = kecil) { Text("Peta") }
            }
        }
    }
}

@Composable
fun FormDialog(awal: Pemasang?, tutup: () -> Unit, simpan: (Pemasang) -> Unit) {
    var nama by remember { mutableStateOf(awal?.nama ?: "") }
    var wilayah by remember { mutableStateOf(awal?.wilayah ?: "") }
    var telp by remember { mutableStateOf(awal?.telepon ?: "") }
    var tarif by remember { mutableStateOf(awal?.tarif ?: "") }
    var catatan by remember { mutableStateOf(awal?.catatan ?: "") }
    var koor by remember { mutableStateOf(awal?.koordinat ?: "") }
    var terpasang by remember { mutableStateOf(awal?.terpasang ?: false) }
    val koorOk = koor.isBlank() || Regex("""^-?\d{1,3}(\.\d+)?\s*,\s*-?\d{1,3}(\.\d+)?$""").matches(koor.trim())
    AlertDialog(
        onDismissRequest = tutup, containerColor = Color.White, shape = RoundedCornerShape(20.dp),
        title = { Text(if (awal == null) "Tambah Pemasang" else "Ubah Pemasang") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(nama, { nama = it }, label = { Text("Nama") }, singleLine = true)
                OutlinedTextField(wilayah, { wilayah = it }, label = { Text("Wilayah") }, singleLine = true)
                OutlinedTextField(telp, { telp = it }, label = { Text("No. HP") }, singleLine = true)
                OutlinedTextField(tarif, { tarif = it }, label = { Text("Tarif / paket") }, singleLine = true)
                OutlinedTextField(koor, { koor = it }, label = { Text("Koordinat (lat, long)") },
                    placeholder = { Text("-6.914744, 107.609810") }, singleLine = true, isError = !koorOk,
                    supportingText = { Text(if (koorOk) "Salin dari Google Maps" else "Format: -6.914744, 107.609810") })
                OutlinedTextField(catatan, { catatan = it }, label = { Text("Catatan") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (terpasang) "Sudah dipasang" else "Belum dipasang", Modifier.weight(1f))
                    Switch(terpasang, { terpasang = it })
                }
            }
        },
        confirmButton = {
            TextButton(enabled = nama.isNotBlank() && telp.isNotBlank() && koorOk, onClick = {
                simpan((awal ?: Pemasang(nama = "", wilayah = "", telepon = "", tarif = "", catatan = ""))
                    .copy(nama = nama.trim(), wilayah = wilayah.trim(), telepon = telp.trim(), tarif = tarif.trim(), catatan = catatan.trim(), koordinat = koor.trim(), terpasang = terpasang))
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(tutup) { Text("Batal") } }
    )
}
