package com.example.pemasangwifi

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@Entity(tableName = "pemasang")
data class Pemasang(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nama: String, val wilayah: String, val telepon: String,
    val tarif: String, val catatan: String, val favorit: Boolean = false,
    val koordinat: String = "", val terpasang: Boolean = false
)

@Dao interface PemasangDao {
    @Query("SELECT * FROM pemasang ORDER BY favorit DESC, nama ASC") fun semua(): Flow<List<Pemasang>>
    @Upsert suspend fun simpan(p: Pemasang)
    @Delete suspend fun hapus(p: Pemasang)
}

val M1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE pemasang ADD COLUMN koordinat TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE pemasang ADD COLUMN terpasang INTEGER NOT NULL DEFAULT 0")
    }
}

@Database(entities = [Pemasang::class], version = 2, exportSchema = false)
abstract class Db : RoomDatabase() { abstract fun dao(): PemasangDao }

class VM(app: Application) : AndroidViewModel(app) {
    private val dao = Room.databaseBuilder(app, Db::class.java, "wifi.db").addMigrations(M1_2).build().dao()
    val data = dao.semua().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    fun simpan(p: Pemasang) = viewModelScope.launch { dao.simpan(p) }
    fun hapus(p: Pemasang) = viewModelScope.launch { dao.hapus(p) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Layar() } }
    }
}

fun nomor62(t: String): String {
    val d = t.filter { it.isDigit() }
    return if (d.startsWith("0")) "62" + d.drop(1) else d
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Layar(vm: VM = viewModel()) {
    val ctx = LocalContext.current
    val data by vm.data.collectAsState()
    var cari by remember { mutableStateOf("") }
    var hanyaFav by remember { mutableStateOf(false) }
    var filterStatus by remember { mutableStateOf<Boolean?>(null) }
    var edit by remember { mutableStateOf<Pemasang?>(null) }
    var dialog by remember { mutableStateOf(false) }

    val tampil = data.filter {
        (!hanyaFav || it.favorit) && (filterStatus == null || it.terpasang == filterStatus) &&
            (it.nama.contains(cari, true) || it.wilayah.contains(cari, true))
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Pemasang WiFi") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { edit = null; dialog = true }) { Icon(Icons.Default.Add, "Tambah") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).padding(12.dp)) {
            OutlinedTextField(cari, { cari = it }, Modifier.fillMaxWidth(),
                label = { Text("Cari nama atau wilayah") }, singleLine = true)
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(hanyaFav, { hanyaFav = !hanyaFav }, { Text("Favorit") })
                FilterChip(filterStatus == false, { filterStatus = if (filterStatus == false) null else false }, { Text("Belum dipasang") })
                FilterChip(filterStatus == true, { filterStatus = if (filterStatus == true) null else true }, { Text("Sudah dipasang") })
            }
            if (tampil.isEmpty()) Text("Belum ada data. Tekan tombol + untuk menambah.")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tampil, key = { it.id }) { p ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(p.nama, style = MaterialTheme.typography.titleMedium)
                            Text("Wilayah: ${p.wilayah}")
                            Text("Telepon: ${p.telepon}")
                            if (p.tarif.isNotBlank()) Text("Tarif: ${p.tarif}")
                            if (p.catatan.isNotBlank()) Text("Catatan: ${p.catatan}")
                            if (p.koordinat.isNotBlank()) Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Koordinat: ${p.koordinat}", Modifier.weight(1f))
                                TextButton({
                                    runCatching {
                                        val q = p.koordinat.replace(" ", "")
                                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q(${Uri.encode(p.nama)})")))
                                    }
                                }) { Icon(Icons.Default.Place, null); Text("Peta") }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (p.terpasang) "Status: Sudah dipasang" else "Status: Belum dipasang", Modifier.weight(1f),
                                    color = if (p.terpasang) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                                Switch(p.terpasang, { vm.simpan(p.copy(terpasang = it)) })
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton({ ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${p.telepon}"))) }) { Icon(Icons.Default.Call, "Telepon") }
                                TextButton({ ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${nomor62(p.telepon)}"))) }) { Text("WA") }
                                Spacer(Modifier.weight(1f))
                                IconButton({ vm.simpan(p.copy(favorit = !p.favorit)) }) {
                                    Icon(if (p.favorit) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorit")
                                }
                                IconButton({ edit = p; dialog = true }) { Icon(Icons.Default.Edit, "Ubah") }
                                IconButton({ vm.hapus(p) }) { Icon(Icons.Default.Delete, "Hapus") }
                            }
                        }
                    }
                }
            }
        }
    }

    if (dialog) FormDialog(edit, { dialog = false }) { vm.simpan(it); dialog = false }
}

@Composable
fun FormDialog(awal: Pemasang?, tutup: () -> Unit, simpan: (Pemasang) -> Unit) {
    var nama by remember { mutableStateOf(awal?.nama ?: "") }
    var wilayah by remember { mutableStateOf(awal?.wilayah ?: "") }
    var telp by remember { mutableStateOf(awal?.telepon ?: "") }
    var tarif by remember { mutableStateOf(awal?.tarif ?: "") }
    var catatan by remember { mutableStateOf(awal?.catatan ?: "") }
    var koor by remember { mutableStateOf(awal?.koordinat ?: "") }
    var terpasang by remember { mutableStateOf(awal?.terpasang ?: false) }
    val koorOk = koor.isBlank() || Regex("""^-?\d{1,3}(\.\d+)?\s*,\s*-?\d{1,3}(\.\d+)?$""").matches(koor.trim())
    AlertDialog(
        onDismissRequest = tutup,
        title = { Text(if (awal == null) "Tambah Pemasang" else "Ubah Pemasang") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(nama, { nama = it }, label = { Text("Nama") }, singleLine = true)
                OutlinedTextField(wilayah, { wilayah = it }, label = { Text("Wilayah") }, singleLine = true)
                OutlinedTextField(telp, { telp = it }, label = { Text("No. HP") }, singleLine = true)
                OutlinedTextField(tarif, { tarif = it }, label = { Text("Tarif / paket") }, singleLine = true)
                OutlinedTextField(koor, { koor = it }, label = { Text("Koordinat (lat, long)") },
                    placeholder = { Text("-6.914744, 107.609810") }, singleLine = true, isError = !koorOk,
                    supportingText = { Text(if (koorOk) "Salin dari Google Maps" else "Format: -6.914744, 107.609810") })
                OutlinedTextField(catatan, { catatan = it }, label = { Text("Catatan") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (terpasang) "Sudah dipasang" else "Belum dipasang", Modifier.weight(1f))
                    Switch(terpasang, { terpasang = it })
                }
            }
        },
        confirmButton = {
            TextButton(enabled = nama.isNotBlank() && telp.isNotBlank() && koorOk, onClick = {
                simpan((awal ?: Pemasang(nama = "", wilayah = "", telepon = "", tarif = "", catatan = ""))
                    .copy(nama = nama.trim(), wilayah = wilayah.trim(), telepon = telp.trim(), tarif = tarif.trim(), catatan = catatan.trim(), koordinat = koor.trim(), terpasang = terpasang))
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(tutup) { Text("Batal") } }
    )
}
